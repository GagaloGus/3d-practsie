using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TextFileManager : AbstractFileManager
{
    public override List<string> Load(string filename)
    {
        throw new System.NotImplementedException();
    }

    public override void Save(string filename, List<string> content)
    {
        throw new System.NotImplementedException();
    }
}
